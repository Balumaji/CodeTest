exports.queryResponse = async(query) => {
    await db.query(query, (err, result) => {
        if (err) {
            console.log("errr-->", err)
            return (err);
        };
        console.log("resultt---", result);
        return result;
    })
};