const mysql = require("mysql");
const dbSocketPath = process.env.DB_SOCKET_PATH || "/cloudsql";
const pool = mysql.createPool({
	connectionLimit: 10,
	user: "freshwork", // e.g. 'my-db-user'
	password: "8RAfTMpR,7", // e.g. 'my-db-password'
	database: "freshwork_rds", // e.g. 'my-database'
	socketPath: `${dbSocketPath}/${process.env.CLOUD_SQL_CONNECTION_NAME}`,
});
class Repository {
	async prepareQuery(query, parameters) {
		console.log("----------------------------prepareQuery called-----------------------------");
		return new Promise((resolve, reject) => {
			pool.getConnection(function (err, connection) {
				connection.query(query, parameters, (err, result) => {
					if (err) {
						console.log(
							"-------------------- while prepare query errrrrrrrr------------------------------>",
							err
						);
						reject(err);
					}
					connection.release();
					resolve(result);
				});
			});
		});
	}
}
exports.Repository = Repository;
