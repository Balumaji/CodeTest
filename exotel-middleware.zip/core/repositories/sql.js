const mysql = require("mysql");
const dbSocketPath = process.env.DB_SOCKET_PATH || "/cloudsql";
const pool = mysql.createPool({
    connectionLimit: 10,
    host: process.env.DB_HOST,
    user: process.env.DB_USER, // e.g. 'my-db-user'
    password: process.env.DB_PASS, // e.g. 'my-db-password'
    port: process.env.DB_PORT,
    database: process.env.DB_NAME, // e.g. 'my-database'
});
class Repository {
    async prepareQuery(query, parameters) {
        console.log("----------------------------prepareQuery called-----------------------------");
        return new Promise((resolve, reject) => {
            pool.getConnection(function (err, connection) {
                connection.query(query, parameters, (err, result) => {
                    if (err) {
                        console.log("-------------------- while prepare query errrrrrrrr------------------------------>", err);
                        reject(err);
                    };
                    connection.release();
                    resolve(result);
                });
            });
        });
    }
};
exports.Repository = Repository;