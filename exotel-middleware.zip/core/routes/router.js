var express = require("express");
var router = express.Router();
const {
  healthCheck,
  accountsCredentials,
  answeredCallEvent,
  userMappingBySync,
  outBoundCallEvent,
  userMappingsearch,
  createCallLog,
  userMapping,
  popEvents,
  allCallsEvents,
  userDetailsStore,
  missedCallEvent,
} = require("../events");
router.get("/healthcheck", healthCheck);
router.post("/accounts", accountsCredentials);
router.get("/pop/:accountSid", popEvents);
router.post("/:accountSid/outBoundCall", outBoundCallEvent);
router.get("/answered/:accountSid", answeredCallEvent);
router.get("/missed/:accountSid", missedCallEvent);
router.get("/:accountSid/:agentId/calls", allCallsEvents);
router.get("/:freshworksAccountType/:accountSid/userMapping", userMapping);
router.get(
  "/:freshworksAccountType/:accountSid/userMappingsearch",
  userMappingsearch
);
router.get(
  "/:freshworksAccountType/:accountSid/userMapping/sync",
  userMappingBySync
);
router.post(
  "/:freshworksAccountType/:accountSid/userMapping",
  userDetailsStore
);
router.post("/:freshworksAccountType/:accountSid/createCallLog", createCallLog);
module.exports = router;
