// module.exports = {

//     // exotelAndFreshworksAccountDetails: (req, res) => {
//     //     let query = "SELECT * FROM `players` WHERE user_name = '" + callSid + "'"; // query database to get all the players
//     //     CreateDatabase(query);
//     // },
//     // GetDatabase: (query) => {
//     //     db.query(query, (err, result) => {
//     //         if (err) {
//     //             return err;
//     //             // res.send('failed------->', err);
//     //         } else {
//     //             console.log("resultttttttt--------->", result);
//     //             return result;
//     //         };
//     //     });
//     // },
//     // CreateDatabase: (query) => {
//     //     db.query(query, (err, result) => {
//     //         if (err) {
//     //             return err;
//     //             // res.send('failed------->', err);
//     //         } else {
//     //             console.log("resultttttttt--------->", result);
//     //             return result;
//     //         };
//     //     });
//     // }
// };